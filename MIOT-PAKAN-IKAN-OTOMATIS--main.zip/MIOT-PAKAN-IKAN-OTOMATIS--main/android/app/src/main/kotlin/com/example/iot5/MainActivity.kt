package com.example.iot5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
