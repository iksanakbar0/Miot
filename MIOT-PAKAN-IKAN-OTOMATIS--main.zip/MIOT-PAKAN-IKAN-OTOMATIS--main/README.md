# MIoT-Teori-Kelas-C
Tugas Ujian Akhir Semester - Sistem Pakan Ikan Otomatis Berbasis IoT

ANGGOTA KELOMPOK:
- 5200411275 Abdul Haris A.
- 5200411292 Syifa Maulaya
- 5200411382 Nur Azizah Ayuningtyas
- 5200411292 Findyka Ayuningtyas
- 5200411435 Ikhsan Akbar
